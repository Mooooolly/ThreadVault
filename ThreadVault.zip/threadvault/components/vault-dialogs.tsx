"use client";

import { useState, type FormEvent } from "react";
import { ArrowRight, ArrowUpRight, FileJson, Folder, ImagePlus, Pencil, Plus, Save, Sparkles, Tag, Trash2, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Modal } from "@/components/ui/dialog";
import type { Category, Post, Suggestion } from "@/lib/types";
import type { Field } from "@/lib/importing";
import { colors } from "@/lib/domain";

export async function mutate<T = unknown>(action: string, data?: unknown, id?: string): Promise<T> {
  const response = await fetch("/api/vault", {
    method: "POST", headers: {"content-type": "application/json"}, body: JSON.stringify({action, data, id}),
  });
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || "操作失败，请重试");
  return result as T;
}
const errorText = (failure: unknown) => failure instanceof Error ? failure.message : "操作失败，请重试";
const names = (value: string) => value.split(/[,，\n]/).map((item) => item.trim()).filter(Boolean);
const labels: Record<Field, string> = {
  url: "原帖链接", source: "来源", sourcePostId: "帖子 ID", authorName: "作者姓名", authorHandle: "作者账号",
  text: "帖子正文", imageUrls: "图片链接", publishedAt: "发布于", importedAt: "导入于",
  note: "个人备注", priority: "重要度", readStatus: "阅读状态", aiSummary: "摘要",
  categories: "分类", tags: "标签", isDemo: "演示标记",
};

function localDate(value?: string | null) {
  if (!value) return "";
  const date = new Date(value);
  return new Date(+date - date.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
}

export function PostEditor({post, categories, tags, onClose, onSaved}: {
  post: Post | null; categories: Category[]; tags: string[]; onClose: () => void; onSaved: (post: Post | null, message: string) => void;
}) {
  const [editing, setEditing] = useState(!post);
  const [draft, setDraft] = useState(() => ({
    url: post?.url ?? "", source: post?.source ?? "Threads", sourcePostId: post?.sourcePostId ?? "",
    authorName: post?.authorName ?? "", authorHandle: post?.authorHandle ?? "", text: post?.text ?? "",
    imageUrls: post?.imageUrls.join("\n") ?? "", publishedAt: localDate(post?.publishedAt), note: post?.note ?? "",
    priority: post?.priority ?? 0, readStatus: post?.readStatus ?? "unread",
    aiSummary: post?.aiSummary ?? "", categories: post?.categories.map(({name}) => name) ?? [],
    tags: post?.tags.map(({name}) => name).join(", ") ?? "",
  }));
  const [busy, setBusy] = useState("");
  const [error, setError] = useState("");
  const [suggestion, setSuggestion] = useState<Suggestion | null>(null);
  function update<K extends keyof typeof draft>(key: K, value: (typeof draft)[K]) {
    setDraft((previous) => ({ ...previous, [key]: value }));
  }
  async function save(event: FormEvent) {
    event.preventDefault(); setBusy("save"); setError("");
    try {
      const { publishedAt, imageUrls, tags: tagText, ...rest } = draft;
      const linked = !!draft.url.trim();
      const values = { ...rest, sourcePostId: linked ? undefined : rest.sourcePostId,
        publishedAt: publishedAt ? new Date(publishedAt).toISOString() : null, imageUrls: imageUrls.split(/\r?\n/).map((item) => item.trim()).filter(Boolean), tags: names(tagText) };
      const saved = await mutate<Post>("savePost", values, post?.id);
      onSaved(saved, post ? "收藏已更新" : "已添加收藏");
      setEditing(false); setSuggestion(null);
    } catch (failure) { setError(errorText(failure)); }
    finally { setBusy(""); }
  }
  async function remove() {
    if (!post || !window.confirm("确定删除这条收藏？")) return;
    setBusy("delete"); setError("");
    try { await mutate("deletePost", undefined, post.id); onSaved(null, "收藏已删除"); }
    catch (failure) { setError(errorText(failure)); }
    finally { setBusy(""); }
  }
  async function recommend() {
    if (!post) return;
    setError(""); setBusy("suggest");
    try { setSuggestion(await mutate<Suggestion>("suggest", undefined, post.id)); }
    catch (failure) { setError(errorText(failure)); }
    finally { setBusy(""); }
  }
  function applySuggestion() {
    if (!suggestion) return;
    setDraft((value) => ({...value,
      categories: [...new Set([...value.categories, ...suggestion.categories])],
      tags: [...new Set([...names(value.tags), ...suggestion.tags])].join(", "),
      aiSummary: value.aiSummary || suggestion.summary,
    }));
    setSuggestion(null); setEditing(true);
  }
  return <Modal side title={post ? "收藏详情" : "添加收藏"} description={post ? undefined : "粘贴 Threads 原帖链接，或手动补充你想保存的内容。"} onClose={onClose}>
    {error && <div className="notice error-notice" role="alert">{error}</div>}
    {editing ? <form className="editor" onSubmit={save}>
      <label>Threads 原帖链接<input className="input" type="url" value={draft.url} onChange={(event) => update("url",event.target.value)} placeholder="https://www.threads.com/@作者/post/编号"/></label>
      <div className="form-grid">
        <label>作者姓名<input className="input" value={draft.authorName} onChange={(event) => update("authorName",event.target.value)} placeholder="作者显示名称"/></label>
        <label>作者账号<input className="input" value={draft.authorHandle} onChange={(event) => update("authorHandle",event.target.value)} placeholder="@handle"/></label>
      </div>
      <label>帖子正文<textarea className="input" rows={5} value={draft.text} onChange={(event) => update("text",event.target.value)} placeholder="粘贴帖子原文"/></label>
      <label><span className="inline-label"><ImagePlus size={15}/> 图片链接</span><textarea className="input" rows={2} value={draft.imageUrls} onChange={(event) => update("imageUrls",event.target.value)} placeholder="每行一个图片链接"/></label>
      <div className="form-grid">
        <label>来源<input className="input" value={draft.source} onChange={(event) => update("source",event.target.value)}/></label>
        <label>发帖时间<input className="input" type="datetime-local" value={draft.publishedAt} onChange={(event) => update("publishedAt",event.target.value)}/></label>
      </div>
      {!draft.url.trim() && <label>帖子 ID<input className="input" value={draft.sourcePostId} onChange={(event) => update("sourcePostId",event.target.value)} placeholder="可选，用于查找重复收藏"/></label>}
      <fieldset><legend>分类</legend><div className="chip-options">{categories.map(({id, name, color}) => <label className={`choice-chip tone-${color}`} key={id}>
        <input type="checkbox" checked={draft.categories.includes(name)} onChange={(event) => update("categories",event.target.checked ? [...draft.categories, name] : draft.categories.filter((value) => value !== name))}/>{name}
      </label>)}</div></fieldset>
      <label>标签<input className="input" value={draft.tags} onChange={(event) => update("tags",event.target.value)} placeholder="用逗号分隔标签"/></label>
      {!!tags.length && <div className="existing-tags">{tags.slice(0, 10).map((tag) => <Button type="button" variant="ghost" key={tag} onClick={() => update("tags",[...new Set([...names(draft.tags),tag])].join(", "))}>#{tag}</Button>)}</div>}
      <div className="form-grid">
        <label>重要度<select className="input" value={draft.priority} onChange={(event) => update("priority",+event.target.value)}><option value="0">普通</option><option value="1">★</option><option value="2">★★</option><option value="3">★★★</option></select></label>
        <label>阅读状态<select className="input" value={draft.readStatus} onChange={(event) => update("readStatus",event.target.value)}><option value="unread">未读</option><option value="reading">阅读中</option><option value="read">已读</option></select></label>
      </div>
      <label>个人备注<textarea className="input" rows={3} value={draft.note} onChange={(event) => update("note",event.target.value)} placeholder="记录你为什么收藏这条内容"/></label>
      <label>摘要<textarea className="input" rows={2} value={draft.aiSummary} onChange={(event) => update("aiSummary",event.target.value)}/></label>
      <div className="dialog-actions"><Button type="button" variant="outline" onClick={onClose}>取消</Button><Button type="submit" disabled={!!busy}><Save size={16}/>{busy === "save" ? "保存中…" : "保存收藏"}</Button></div>
    </form> : post && <div className="detail-content">
      <div className="detail-profile"><span className="avatar tone-violet">{(post.authorName || post.authorHandle || "?")[0]}</span><div><strong>{post.authorName || post.authorHandle || "未知作者"}</strong><small>{post.authorHandle ? `@${post.authorHandle}` : post.source}</small></div>{post.isDemo && <span className="demo-pill">演示数据</span>}</div>
      <p className="full-text">{post.text || "尚未补充正文"}</p>
      {post.imageUrls.map((src) => <img key={src} className="detail-image" src={src} alt="帖子配图" referrerPolicy="no-referrer" onError={(event) => {event.currentTarget.hidden = true;}}/>)}
      <div className="detail-record"><span>来源</span><strong>{post.source}</strong><span>导入时间</span><time dateTime={post.importedAt}>{new Date(post.importedAt).toLocaleString("zh-CN")}</time>
        {post.publishedAt && <><span>发帖时间</span><time dateTime={post.publishedAt}>{new Date(post.publishedAt).toLocaleString("zh-CN")}</time></>}
        <span>阅读状态</span><strong>{({read:"已读",reading:"阅读中",unread:"未读"} as Record<string,string>)[post.readStatus]}</strong><span>重要度</span><strong>{post.priority ? "★".repeat(post.priority) : "普通"}</strong>
      </div>
      {post.url && <a className="source-link" href={post.url} target="_blank" rel="noreferrer">查看 Threads 原帖 <ArrowUpRight size={15}/></a>}
      <section className="detail-section"><h3><Folder size={16}/>分类</h3><div className="chip-options">{post.categories.length ? post.categories.map(({id, name, color}) => <span className={`pill tone-${color}`} key={id}>{name}</span>) : <span className="muted">尚未分类</span>}</div></section>
      <section className="detail-section"><h3><Tag size={16}/>标签</h3><div className="chip-options">{post.tags.length ? post.tags.map(({id, name}) => <span key={id} className="tag-label">#{name}</span>) : <span className="muted">还没有标签</span>}</div></section>
      <section className="detail-section"><h3>个人备注</h3><p>{post.note || "还没有备注"}</p></section>
      {post.aiSummary && <section className="detail-section"><h3>摘要</h3><p>{post.aiSummary}</p></section>}
      {suggestion && <div className="suggestion">
        <h3>{suggestion.method === "model" ? "模型推荐" : "关键词推荐"}</h3>
        <p>{suggestion.summary || "补充原文后可生成摘要。"}</p>
        <div className="chip-options">{[...suggestion.categories, ...suggestion.tags.map((tag) => `#${tag}`)].map((label) => <span className="pill tone-violet" key={label}>{label}</span>)}</div>
        <Button variant="outline" onClick={applySuggestion}>合并到草稿 <ArrowRight size={14}/></Button>
      </div>}
      <div className="dialog-actions detail-actions">
        <Button variant="ghost" className="danger-text" aria-label="删除收藏" disabled={!!busy} onClick={remove}><Trash2 size={17}/></Button>
        <Button variant="outline" disabled={!!busy || !post.text.trim()} onClick={recommend}><Sparkles size={16}/>{busy === "suggest" ? "推荐中…" : "推荐分类"}</Button>
        <Button onClick={() => setEditing(true)} disabled={!!busy}><Pencil size={15}/>编辑收藏</Button>
      </div>
    </div>}
  </Modal>;
}

type Preview = {
  headers: string[]; mapping: Record<string,string>; valid: number; duplicates: number; invalid: number; total: number;
  errors: { row: number; message: string }[]; backup: boolean;
  sample: {text: string; url: string | null; authorName: string; authorHandle: string}[];
};
export function ImportDialog({onClose, onSaved}: {onClose: () => void; onSaved: (message: string) => void}) {
  const [file, setFile] = useState<{name: string; format: "json" | "csv"; content: string}>();
  const [preview, setPreview] = useState<Preview>();
  const [mapping, setMapping] = useState<Record<string, string>>({});
  const [replace, setReplace] = useState(false);
  const [dirty, setDirty] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  async function inspect(source: NonNullable<typeof file>, nextMapping?: Record<string,string>, nextReplace = false) {
    setBusy(true); setError("");
    try {
      const result = await mutate<Preview>("previewImport", {...source, mapping: nextMapping, replace: nextReplace});
      setPreview(result); setMapping(result.mapping); setReplace(nextReplace); setDirty(false);
    } catch (failure) { setError(errorText(failure)); setDirty(true); }
    finally { setBusy(false); }
  }
  async function choose(selected?: File) {
    if (!selected) return;
    setFile(undefined); setPreview(undefined); setReplace(false); setDirty(false); setError("");
    const format = selected.name.split(".").pop()?.toLowerCase();
    if (format !== "json" && format !== "csv") { setError("请选择 JSON 或 CSV 文件"); return; }
    if (selected.size > 12_000_000) { setError("文件不能超过 12 MB"); return; }
    try {
      const source: NonNullable<typeof file> = { name: selected.name, format, content: await selected.text() };
      setFile(source); await inspect(source);
    } catch (failure) { setError(errorText(failure)); }
  }
  async function confirm() {
    if (!file || !preview || dirty) return;
    if (replace && !window.confirm("覆盖恢复会替换当前收藏、分类和标签。确定继续？")) return;
    setBusy(true); setError("");
    try {
      const result = await mutate<Preview>("commitImport", {...file, mapping, replace});
      onSaved(`${replace ? "恢复" : "导入"}完成 · ${result.valid} 条，跳过 ${result.duplicates} 条重复、${result.invalid} 条无效`);
    } catch (failure) { setError(errorText(failure)); }
    finally { setBusy(false); }
  }
  return <Modal wide title="导入收藏与恢复备份" description="选择 JSON 或 CSV，检查字段与预览后再写入本地知识库。" onClose={onClose}>
    <label className="file-drop"><span className="stat-icon tone-violet"><Upload size={20}/></span><strong>{file?.name || "选择 JSON 或 CSV 文件"}</strong><small>最多 12 MB · 10,000 条帖子</small><input type="file" accept=".json,.csv" disabled={busy} onChange={(event) => {void choose(event.target.files?.[0]); event.target.value = "";}}/></label>
    {error && <div className="notice error-notice" role="alert">{error}</div>}
    {busy && <p role="status" className="muted">正在处理文件…</p>}
    {preview && file && <div className="import-preview">
      {preview.backup && <label className="replace-choice"><input type="checkbox" checked={replace} disabled={busy} onChange={(event) => void inspect(file, undefined, event.target.checked)}/>使用此备份覆盖当前数据</label>}
      <div className="preview-counts"><span className="pill tone-green">可写入 {preview.valid}</span><span className="pill tone-orange">重复 {preview.duplicates}</span><span className="pill tone-pink">错误 {preview.invalid}</span><span className="muted">共 {preview.total} 条</span></div>
      {!replace && !!preview.headers.length && <details className="mapping"><summary>字段映射</summary><div className="form-grid">
        {(Object.keys(labels) as Field[]).map((field) => <label key={field}>{labels[field]}<select className="input" value={mapping[field] ?? ""} disabled={busy} onChange={(event) => {
          setMapping({...mapping, [field]:event.target.value}); setDirty(true);
        }}><option value="">不导入</option>{preview.headers.map((header) => <option key={header}>{header}</option>)}</select></label>)}
      </div></details>}
      {dirty && <Button variant="outline" disabled={busy} onClick={() => void inspect(file, mapping, replace)}>重新预览</Button>}
      {!!preview.errors.length && <details className="mapping" open><summary>行错误</summary><ul className="row-errors">{preview.errors.map(({row, message}) => <li key={row}>第 {row} 行 · {message}</li>)}</ul></details>}
      {!!preview.sample.length && <div className="sample-list"><h3>预览前 {preview.sample.length} 条</h3>{preview.sample.map(({text, url, authorName, authorHandle}, index) => <div key={index}><FileJson size={16}/><span><strong>{authorName || authorHandle || "未知作者"}</strong><small>{text || url || "图片收藏"}</small></span></div>)}</div>}
    </div>}
    <div className="dialog-actions"><Button variant="outline" onClick={onClose}>取消</Button><Button onClick={confirm} disabled={busy || dirty || !preview || (!preview.valid && !preview.backup) || (replace && !!(preview.invalid || preview.duplicates))}>{replace ? "确认覆盖恢复" : "确认导入"}</Button></div>
  </Modal>;
}

export function CategoryManager({categories, onClose, onSaved}: {
  categories: Category[]; onClose: () => void; onSaved: (message: string, deletedId?: string) => void;
}) {
  const [editId, setEditId] = useState<string>();
  const [name, setName] = useState("");
  const [color, setColor] = useState<string>("violet");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  async function save(event: FormEvent) {
    event.preventDefault(); setError(""); setBusy(true);
    try { await mutate("saveCategory", {name, color}, editId); onSaved(editId ? "分类已更新" : "分类已添加"); setName(""); setEditId(undefined); }
    catch (failure) { setError(errorText(failure)); }
    finally { setBusy(false); }
  }
  async function remove(category: Category) {
    if (!window.confirm(`确定删除分类「${category.name}」？其中的收藏会保留。`)) return;
    setError(""); setBusy(true);
    try {
      await mutate("deleteCategory", undefined, category.id);
      if (editId === category.id) { setName("");setEditId(undefined); }
      onSaved("分类已删除", category.id);
    } catch (failure) { setError(errorText(failure)); }
    finally { setBusy(false); }
  }
  return <Modal title="管理分类" description="创建、重命名或删除知识库的主题分类。" onClose={onClose}>
    {error && <div className="notice error-notice" role="alert">{error}</div>}
    <form className="editor" onSubmit={save}>
      <label>分类名称<input className="input" value={name} maxLength={60} required placeholder="例如：设计参考" onChange={(event) => setName(event.target.value)}/></label>
      <div className="action-line"><span className="muted">颜色</span>{colors.map((item) => <button type="button" key={item} className={`color-choice tone-${item}`} aria-label={item} aria-pressed={item === color} onClick={() => setColor(item)}/>)}</div>
      <div className="action-line"><Button type="submit" disabled={busy || !name.trim()}>{editId ? <Save size={15}/> : <Plus size={15}/>} {editId ? "保存修改" : "新增分类"}</Button>{editId && <Button type="button" variant="ghost" onClick={() => {setEditId(undefined);setName("");}}>取消编辑</Button>}</div>
    </form>
    <div className="category-manager-list">{categories.map((category) => <div key={category.id}><i className={`color-dot tone-${category.color}`}/><strong>{category.name}</strong>
      <Button variant="ghost" className="icon-button" aria-label={`重命名 ${category.name}`} disabled={busy} onClick={() => {setEditId(category.id);setName(category.name);setColor(category.color);}}><Pencil size={15}/></Button>
      <Button variant="ghost" className="icon-button danger-text" aria-label={`删除 ${category.name}`} disabled={busy} onClick={() => void remove(category)}><Trash2 size={16}/></Button></div>)}</div>
  </Modal>;
}
