import type { NextConfig } from "next";

const config: NextConfig = {
  serverExternalPackages: ["better-sqlite3"],
  experimental: { cpus: 2 },
  devIndicators: false,
  poweredByHeader: false,
};
export default config;
