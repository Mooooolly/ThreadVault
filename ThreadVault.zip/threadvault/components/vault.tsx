"use client";

import { useEffect, useRef, useState, type FormEvent, type ReactNode } from "react";
import {
  Archive, ArrowDownWideNarrow, ArrowLeft, ArrowRight, ArrowUpRight, Bookmark, BookOpen, Check,
  ChevronDown, ChevronsUpDown, Clock3, Database, Download, Folder, FolderOpen, Gamepad2,
  Heart, LayoutGrid, List, Menu, Moon, Plus, Search, Settings2, Sparkles, Star, Sun, Tag,
  TrendingUp, Upload, X,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import type { Post, VaultData } from "@/lib/types";
import { CategoryManager, ImportDialog, PostEditor, mutate } from "@/components/vault-dialogs";

type Scope = "all" | "categories" | "recent" | "pending" | "settings";
const nav = [
  ["all", "全部收藏", Bookmark], ["categories", "智能分类", Sparkles],
  ["recent", "最近添加", Clock3], ["pending", "待整理", Archive], ["settings", "设置", Settings2],
] as const;
const icons = { violet: Sparkles, orange: TrendingUp, blue: Gamepad2, green: BookOpen, pink: Heart, slate: Folder };
const avatarColors = ["violet", "orange", "green", "blue", "pink", "slate"];
const statusLabels: Record<string, string> = { unread: "未读", reading: "阅读中", read: "已读" };
const headings: Record<Scope, [string, string]> = {
  all: ["全部收藏", "保存值得回看的灵感、知识和好内容。"],
  categories: ["智能分类", "按主题浏览收藏，也可以创建和管理自己的分类。"],
  recent: ["最近添加", "回顾过去 7 天收进知识库的内容。"],
  pending: ["待整理", "给尚未归类的收藏找到合适的位置。"],
  settings: ["设置", "管理外观、分类和你的本地数据。"],
};

export const dateLabel = (value: string) => new Intl.DateTimeFormat("zh-CN", { month: "short", day: "numeric", timeZone: "Asia/Shanghai" }).format(new Date(value));

function IconSelect({ label, value, onChange, children, icon }: {
  label: string; value: string; onChange: (value: string) => void; children: ReactNode; icon?: ReactNode;
}) {
  return <label className="icon-select">{icon}<select aria-label={label} value={value} onChange={(event) => onChange(event.target.value)}>{children}</select><ChevronDown size={13}/></label>;
}

function PostCard({post, open, selected, toggle, list}: {
  post: Post; open: () => void; selected: boolean; toggle: () => void; list: boolean;
}) {
  const displayName = post.authorName || post.authorHandle || "未知作者";
  const shade = avatarColors[(post.authorHandle || displayName).split("").reduce((sum, char) => sum + char.charCodeAt(0), 0) % avatarColors.length];
  return <article className={`post-card ${list ? "post-row" : ""} ${selected ? "selected" : ""}`}>
    <button className="card-open" type="button" onClick={open} aria-label={`查看 ${displayName} 的收藏`} />
    <div className="card-author">
      <span className={`avatar tone-${shade}`}>{displayName.slice(0, 1).toUpperCase()}</span>
      <div className="author-name"><strong>{displayName}</strong><small>{post.authorHandle ? `@${post.authorHandle}` : post.source}</small></div>
      {post.isDemo && <span className="demo-pill">演示</span>}
      <label className="check-toggle" title="选择收藏"><input type="checkbox" checked={selected} onChange={toggle} aria-label={`选择 ${displayName} 的收藏`}/></label>
    </div>
    <p className="card-text">{post.text.trim() || "尚未补充正文"}</p>
    {post.imageUrls[0] && !list && <div className="card-image"><img src={post.imageUrls[0]} alt="帖子配图" loading="lazy" referrerPolicy="no-referrer" onError={(event) => {event.currentTarget.hidden = true;}} /></div>}
    <div className="card-foot">
      <div className="card-labels">
        {post.categories.slice(0, list ? 2 : 1).map((category) => <span key={category.id} className={`pill tone-${category.color}`}>{category.name}</span>)}
        {post.tags.slice(0, list ? 1 : 2).map(({id, name}) => <span className="tag-label" key={id}>#{name}</span>)}
      </div>
      <div className="card-meta">{post.priority > 0 && <Star size={13} className="priority-star" aria-label={`重要度 ${post.priority}`}/>}<time dateTime={post.importedAt}>{dateLabel(post.importedAt)}</time></div>
    </div>
  </article>;
}

export function Vault({ initial, initialError = "" }: { initial: VaultData; initialError?: string }) {
  const [data, setData] = useState(initial);
  const [scope, setScope] = useState<Scope>("all");
  const [query, setQuery] = useState("");
  const [author, setAuthor] = useState("");
  const [category, setCategory] = useState("");
  const [tag, setTag] = useState("");
  const [status, setStatus] = useState("");
  const [sort, setSort] = useState("imported");
  const [view, setView] = useState("grid");
  const [dark, setDark] = useState(false);
  const [mobileNav, setMobileNav] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [selection, setSelection] = useState<string[]>([]);
  const [detail, setDetail] = useState<Post | null | undefined>(undefined);
  const [importOpen, setImportOpen] = useState(false);
  const [categoryOpen, setCategoryOpen] = useState(false);
  const [error, setError] = useState(initialError);
  const [toast, setToast] = useState("");
  const [loading, setLoading] = useState(false);
  const [version, setVersion] = useState(0);
  const [bulk, setBulk] = useState("");
  const [bulkBusy, setBulkBusy] = useState(false);
  const searchRef = useRef<HTMLInputElement>(null);
  const pageScope = scope === "settings" ? "all" : scope;
  const params = new URLSearchParams({ q: query, scope: pageScope, author, category, tag, status, sort }).toString();
  const current = useRef(params);
  current.current = params;
  const [title, description] = headings[scope];
  const filtered = !!(query || author || category || tag || status);
  const chosenCategory = data.categories.find(({id}) => id === category);
  const counts = {all: data.stats.total, recent: data.stats.recent, pending: data.stats.pending, categories: null, settings: null};

  useEffect(() => {
    setDark(document.documentElement.classList.contains("dark"));
    if (localStorage.getItem("threadvault-view") === "list") setView("list");
    const focus = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") { event.preventDefault(); searchRef.current?.focus(); }
    };
    window.addEventListener("keydown", focus);
    return () => window.removeEventListener("keydown", focus);
  }, []);

  useEffect(() => {
    const controller = new AbortController();
    setLoading(true);
    const timer = setTimeout(async () => {
      try {
        const response = await fetch(`/api/vault?${params}`, { signal: controller.signal });
        const result = await response.json();
        if (!response.ok) throw new Error(result.error || "读取收藏失败");
        if (current.current === params) { setData(result); setError(""); }
      } catch (failure) {
        if (!controller.signal.aborted) setError(failure instanceof Error ? failure.message : "读取收藏失败");
      } finally { if (!controller.signal.aborted) setLoading(false); }
    }, 160);
    return () => { clearTimeout(timer); controller.abort(); };
  }, [params, version]);

  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(() => setToast(""), 3400);
    return () => clearTimeout(timer);
  }, [toast]);

  function toggleTheme() {
    const next = !document.documentElement.classList.contains("dark");
    document.documentElement.classList.toggle("dark", next);
    localStorage.setItem("threadvault-theme", next ? "dark" : "light");
    setDark(next);
  }
  function chooseView(value: string) { setView(value); localStorage.setItem("threadvault-view", value); }
  function clearFilters() { setQuery(""); setAuthor(""); setCategory(""); setTag(""); setStatus(""); setSelection([]); }
  function navigate(next: Scope, folder = "") {
    clearFilters(); setScope(next); setCategory(folder); setMobileNav(false);
  }
  function refreshed(message: string) {
    setVersion((prev) => prev + 1); setToast(message); setSelection([]);
  }
  function toggleSelection(id: string) {
    setSelection((selected) => selected.includes(id) ? selected.filter((value) => value !== id) : [...selected, id]);
  }
  async function applyBulk(event: FormEvent) {
    event.preventDefault();
    if (!bulk) return;
    if (bulk === "delete" && !window.confirm(`确定删除选中的 ${selection.length} 条收藏？`)) return;
    const [operation, value] = bulk.split(":");
    setBulkBusy(true);
    try {
      await mutate("bulk", { ids: selection, operation, readStatus: operation === "status" ? value : undefined, categoryId: operation === "category" ? value : undefined });
      setBulk(""); refreshed("批量操作已完成");
    } catch (failure) { setError(failure instanceof Error ? failure.message : "批量操作失败"); }
    finally { setBulkBusy(false); }
  }

  return <div className="workspace-shell">
    {mobileNav && <button className="mobile-shade" aria-label="关闭导航" onClick={() => setMobileNav(false)} />}
    <aside className={`sidebar ${mobileNav ? "sidebar-open" : ""}`} aria-label="主导航">
      <button className="brand" onClick={() => navigate("all")}>
        <span className="brand-icon"><Bookmark size={21} strokeWidth={2.3} /></span>
        <span><strong>ThreadVault</strong><small>私人知识库</small></span>
      </button>
      <div className="sidebar-content">
        <p className="nav-label">工作区</p>
        <nav className="nav-group">
          {nav.map(([key, label, Icon]) => <button key={key} className={`nav-item ${scope === key && !category ? "active" : ""}`} aria-current={scope === key && !category ? "page" : undefined} onClick={() => navigate(key)}>
            <Icon size={17}/><span>{label}</span>{counts[key] !== null && <small>{counts[key]}</small>}
          </button>)}
        </nav>
        <div className="nav-label nav-label-action"><span>我的分类</span><button title="管理分类" aria-label="管理分类" onClick={() => setCategoryOpen(true)}><Plus size={16}/></button></div>
        <nav className="nav-group category-nav">
          {data.categories.map((folder) => <button key={folder.id} className={`nav-item ${category === folder.id ? "active" : ""}`} onClick={() => navigate("categories", folder.id)}>
            <i className={`color-dot tone-${folder.color}`} /><span>{folder.name}</span><small>{folder.count}</small>
          </button>)}
        </nav>
      </div>
      <button className="sidebar-bottom" onClick={() => navigate("settings")} title="本地工作区设置">
        <span className="local-icon"><Database size={16}/></span><span><strong>本地工作区</strong><small><i/> SQLite 已配置</small></span><ChevronsUpDown size={14}/>
      </button>
    </aside>

    <div className="main-shell">
      <header className="topbar">
        <Button variant="ghost" className="icon-button mobile-menu" aria-label="打开导航" onClick={() => setMobileNav(true)}><Menu size={22}/></Button>
        <div className="breadcrumb"><span>工作区</span><span className="breadcrumb-divider">/</span><strong>{chosenCategory?.name || title}</strong></div>
        <div className="top-actions">
          <label className="global-search"><Search size={17}/><input ref={searchRef} aria-label="搜索收藏" placeholder="搜索收藏、作者或标签..." value={query} onChange={(event) => {
            if (scope === "settings") setScope("all"); setQuery(event.target.value); setSelection([]);
          }}/>{query ? <button type="button" aria-label="清除搜索" onClick={() => setQuery("")}><X size={14}/></button> : <kbd>Ctrl K</kbd>}</label>
          <Button variant="ghost" className="icon-button theme-toggle" title={dark ? "切换浅色" : "切换暗色"} aria-label={dark ? "切换浅色" : "切换暗色"} onClick={toggleTheme}>{dark ? <Sun size={19}/> : <Moon size={18}/>}</Button>
        </div>
      </header>

      <main className="main-content">
        <section className="intro">
          <div><div className="eyebrow"><span className="eyebrow-icon">{scope === "settings" ? <Settings2 size={13}/> : <Bookmark size={13}/>}</span> {scope === "settings" ? "偏好与数据" : "个人知识库"}</div>
            <h1>{chosenCategory?.name || title}</h1><p>{description}</p>
          </div>
          {scope !== "settings" && <div className="intro-actions">
            <Button variant="outline" onClick={() => setImportOpen(true)}><Upload size={17}/> <span>导入</span></Button>
            <Button onClick={() => setDetail(null)}><Plus size={18}/> <span>添加收藏</span></Button>
          </div>}
        </section>

        {error && <div className="notice error-notice" role="alert"><span>{error}</span><Button variant="ghost" onClick={() => setVersion((value) => value + 1)}>重试</Button></div>}

        {scope === "settings" ? <div className="settings-grid">
          <section className="settings-card"><span className="stat-icon tone-violet"><Database size={19}/></span><h2>数据与备份</h2><p>下载 JSON 完整备份，或将收藏导出为 CSV。</p><div className="action-line">
            <Button asChild variant="outline"><a href="/api/vault?export=json"><Download size={16}/>JSON</a></Button>
            <Button asChild variant="outline"><a href="/api/vault?export=csv"><Download size={16}/>CSV</a></Button>
            <Button variant="outline" onClick={() => setImportOpen(true)}><Upload size={16}/>恢复备份</Button>
          </div></section>
          <section className="settings-card"><span className="stat-icon tone-blue"><Settings2 size={19}/></span><h2>外观与分类</h2><p>调整工作台主题，管理分类名称和颜色。</p><div className="action-line">
            <Button variant="outline" onClick={toggleTheme}>{dark ? <Sun size={16}/> : <Moon size={16}/>}切换主题</Button>
            <Button variant="outline" onClick={() => setCategoryOpen(true)}><Folder size={16}/>管理分类</Button>
          </div></section>
          <section className="settings-card"><span className="stat-icon tone-orange"><Sparkles size={19}/></span><h2>智能推荐</h2><p>默认使用本地关键词规则。启用模型后，只有点击推荐时，收藏正文才会发送给已配置的模型服务。</p></section>
        </div> : <>
          {scope === "all" && <div className="stats-grid">
            {([
              ["all", "全部收藏", "保存的帖子", Bookmark, "violet"], ["recent", "最近添加", "过去 7 天", Clock3, "blue"],
              ["pending", "待整理", "尚未分类", Archive, "orange"],
            ] as const).map(([key, label, hint, Icon, color]) => <button className="stat-card" key={key} onClick={() => navigate(key)}>
              <span className={`stat-icon tone-${color}`}><Icon size={20}/></span><span className="stat-content"><span>{label}</span><strong>{counts[key]}</strong></span><span className="stat-hint">{hint}</span><ArrowUpRight className="stat-arrow" size={15}/>
            </button>)}
          </div>}
          {scope === "categories" && !category && <div className="category-grid">
            {data.categories.map((item) => { const Icon = icons[item.color as keyof typeof icons] ?? Folder; return <button className="category-tile" key={item.id} onClick={() => navigate("categories", item.id)}><span className={`stat-icon tone-${item.color}`}><Icon size={17}/></span><span>{item.name}<small>{item.count} 条</small></span><ArrowRight size={14}/></button>; })}
            <Button variant="outline" onClick={() => setCategoryOpen(true)}><Plus size={16}/>管理分类</Button>
          </div>}
          <section className="collection">
            <div className="collection-heading"><div><h2>{filtered ? "筛选结果" : "收藏列表"}</h2><span className="count-pill">{data.posts.length} 条</span></div>
              <div className="view-toggle" aria-label="视图">
                <button aria-label="卡片视图" aria-pressed={view === "grid"} onClick={() => chooseView("grid")}><LayoutGrid size={17}/></button>
                <button aria-label="列表视图" aria-pressed={view === "list"} onClick={() => chooseView("list")}><List size={18}/></button>
              </div>
            </div>
            <div className="filterbar">
              <div className="filter-left">
                <IconSelect label="分类" value={category} onChange={(value) => {setCategory(value); setSelection([]);}} icon={<Folder size={15}/>}>
                  <option value="">所有分类</option>{data.categories.map(({id, name}) => <option key={id} value={id}>{name}</option>)}
                </IconSelect>
                <IconSelect label="标签" value={tag} onChange={(value) => {setTag(value); setSelection([]);}} icon={<Tag size={15}/>}>
                  <option value="">所有标签</option>{data.tags.map((name) => <option key={name}>{name}</option>)}
                </IconSelect>
                <Button variant={showFilters ? "outline" : "ghost"} className="extra-toggle" onClick={() => setShowFilters(!showFilters)} aria-expanded={showFilters} aria-label="更多筛选"><Settings2 size={16}/> <span>更多筛选</span></Button>
                {filtered && <Button variant="ghost" onClick={clearFilters} className="clear-button"><X size={14}/>清除</Button>}
              </div>
              <IconSelect label="排序" value={sort} onChange={setSort} icon={<ArrowDownWideNarrow size={16}/>}>
                <option value="imported">最近导入</option><option value="published">发布时间</option><option value="priority">重要度</option>
              </IconSelect>
            </div>
            {showFilters && <div className="extra-filters">
              <label><span>作者</span><input className="input" placeholder="姓名或 @账号" value={author} onChange={(event) => {setAuthor(event.target.value); setSelection([]);}}/></label>
              <label><span>阅读状态</span><select className="input" value={status} onChange={(event) => {setStatus(event.target.value); setSelection([]);}}><option value="">全部状态</option>{Object.entries(statusLabels).map(([key, label]) => <option key={key} value={key}>{label}</option>)}</select></label>
            </div>}
            {selection.length > 0 && <form className="bulk-bar" onSubmit={applyBulk}>
              <strong>已选择 {selection.length} 条</strong><Button type="button" variant="ghost" onClick={() => setSelection(data.posts.map(({id}) => id))}>全选结果</Button>
              <select className="input" value={bulk} onChange={(event) => setBulk(event.target.value)} aria-label="批量操作"><option value="">选择操作</option>
                {Object.entries(statusLabels).map(([key, label]) => <option key={key} value={`status:${key}`}>标记为{label}</option>)}
                {data.categories.map(({id, name}) => <option key={id} value={`category:${id}`}>加入 {name}</option>)}<option value="delete">删除选中</option>
              </select><Button type="submit" disabled={!bulk || bulkBusy}>应用</Button><Button type="button" variant="ghost" className="icon-button" aria-label="取消选择" onClick={() => {setSelection([]);setBulk("");}}><X size={16}/></Button>
            </form>}
            {loading && <div className="loading-line" role="status"><span className="sr-only">正在读取收藏</span></div>}
            {!data.posts.length && !loading ? <div className="empty-state"><span className="stat-icon tone-violet">{filtered ? <Search size={22}/> : <FolderOpen size={24}/>}</span>
              <h3>{filtered ? "没有匹配的收藏" : "这里还没有收藏"}</h3><p>{filtered ? "试试其他关键词或清除筛选。" : "粘贴链接、记录正文，或从文件导入收藏。"}</p>
              <Button variant="outline" onClick={() => filtered ? clearFilters() : setDetail(null)}>{filtered ? <ArrowLeft size={16}/> : <Plus size={16}/>} {filtered ? "清除筛选" : "添加收藏"}</Button>
            </div> : <div className={view === "grid" ? "posts-grid" : "posts-list"} aria-busy={loading}>
              {data.posts.map((post) => <PostCard key={post.id} post={post} open={() => setDetail(post)} list={view === "list"} selected={selection.includes(post.id)} toggle={() => toggleSelection(post.id)}/>)}
            </div>}
          </section>
        </>}
      </main>
    </div>
    {detail !== undefined && <PostEditor post={detail} categories={data.categories} tags={data.tags} onClose={() => setDetail(undefined)} onSaved={(post, message) => {setDetail(post ?? undefined);refreshed(message);}}/>}
    {importOpen && <ImportDialog onClose={() => setImportOpen(false)} onSaved={(message) => {setImportOpen(false); refreshed(message);}}/>}
    {categoryOpen && <CategoryManager categories={data.categories} onClose={() => setCategoryOpen(false)} onSaved={(message, deletedId) => {if (deletedId === category) setCategory(""); refreshed(message);}}/>}
    {toast && <div className="toast" role="status"><Check size={17}/>{toast}<button aria-label="关闭提示" onClick={() => setToast("")}><X size={15}/></button></div>}
  </div>;
}
