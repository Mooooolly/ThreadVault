import "dotenv/config";
import { mkdirSync, readdirSync, readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import Database from "better-sqlite3";

const url = process.env.DATABASE_URL || "file:./prisma/threadvault.db";
if (!url.startsWith("file:") || !url.slice(5)) throw new Error("DATABASE_URL must point to a SQLite file");
const filename = resolve(decodeURIComponent(url.slice(5)));
mkdirSync(dirname(filename), { recursive: true });
const database = new Database(filename);
try {
  database.pragma("journal_mode = WAL");
  database.exec("CREATE TABLE IF NOT EXISTS ThreadVaultMigration (name TEXT PRIMARY KEY)");
  const names = readdirSync("prisma/migrations", { withFileTypes: true })
    .filter((entry) => entry.isDirectory()).map((entry) => entry.name).sort();
  const migrate = database.transaction(() => {
    for (const name of names) {
      if (database.prepare("SELECT name FROM ThreadVaultMigration WHERE name = ?").get(name)) continue;
      database.exec(readFileSync(`prisma/migrations/${name}/migration.sql`, "utf8"));
      database.prepare("INSERT INTO ThreadVaultMigration (name) VALUES (?)").run(name);
    }
  });
  migrate.immediate();
  console.log("SQLite migrations ready.");
} finally {
  database.close();
}
