import Papa from "papaparse";
import { z } from "zod";
import { db } from "@/lib/db";
import { InputError, normalizeDraft, type Draft } from "@/lib/domain";
import { relations, rowData, serialize } from "@/lib/posts";

export const fields = ["url", "source", "sourcePostId", "authorName", "authorHandle", "text", "imageUrls", "publishedAt",
  "importedAt", "note", "priority", "readStatus", "aiSummary", "categories", "tags", "isDemo"] as const;
export type Field = typeof fields[number];
type Mapping = Partial<Record<Field, string>>;
type SourceRow = Record<string, unknown>;
const aliases: Partial<Record<Field, string[]>> = {
  url: ["link", "链接", "原帖链接"], text: ["content", "body", "正文", "内容"],
  authorName: ["author", "作者"], authorHandle: ["handle", "账号"], sourcePostId: ["postId", "帖子ID"],
  imageUrls: ["images", "图片链接"], publishedAt: ["created_at", "发布时间"], categories: ["分类"], tags: ["标签"],
};
const categoryRow = z.object({ name: z.string().trim().min(1).max(60), color: z.enum(["slate", "blue", "violet", "orange", "green", "pink"]) });
const backupMetadata = z.object({ categories: z.array(categoryRow).max(10000), tags: z.array(z.string().trim().min(1).max(60)).max(20000) });

function parseFile(content: string, format: "json" | "csv") {
  if (content.length > 12_000_000) throw new InputError("单个导入文件不能超过 12 MB");
  let rows: unknown;
  let metadata: z.infer<typeof backupMetadata> | null = null;
  let headers: string[] = [];
  const clean = content.replace(/^\uFEFF/, "");
  if (format === "csv") {
    const parsed = Papa.parse<SourceRow>(clean, { header: true, skipEmptyLines: "greedy", transformHeader: (header) => header.trim() });
    if (parsed.errors.length) throw new InputError(`CSV 第 ${(parsed.errors[0].row ?? 0) + 2} 行：${parsed.errors[0].message}`);
    rows = parsed.data;
    headers = parsed.meta.fields ?? [];
  } else {
    let document;
    try { document = JSON.parse(clean); } catch { throw new InputError("JSON 格式无效"); }
    rows = Array.isArray(document) ? document : document?.posts;
    if (document?.format === "threadvault") {
      if (document.version !== 1) throw new InputError("备份版本暂不支持");
      metadata = backupMetadata.parse(document);
    }
  }
  if (!Array.isArray(rows) || rows.length > 10000) throw new InputError("文件需包含帖子数组，且最多 10,000 条");
  if (format === "json") {
    headers = [...new Set(rows.flatMap((row) => row && typeof row === "object" && !Array.isArray(row) ? Object.keys(row) : []))];
  }
  return { rows, headers, metadata };
}

function arrayValue(value: unknown): unknown {
  if (typeof value !== "string") return value;
  const trimmed = value.trim();
  if (!trimmed) return [];
  if (trimmed.startsWith("[")) {
    try { return JSON.parse(trimmed); } catch { throw new InputError("数组字段的 JSON 格式无效"); }
  }
  return trimmed.split(/[|，]/).map((item) => item.trim()).filter(Boolean);
}

function mapRow(row: SourceRow, mapping: Mapping) {
  const values: SourceRow = {};
  for (const field of fields) {
    const header = mapping[field];
    if (!header || !Object.hasOwn(row, header)) continue;
    let value = row[header];
    if (value == null || value === "") continue;
    if (["tags", "categories", "imageUrls"].includes(field)) value = arrayValue(value);
    if (field === "isDemo") value = value === true || value === "true" || value === "1";
    values[field] = value;
  }
  return normalizeDraft(values);
}

export const importRequest = z.object({
  content: z.string(), format: z.enum(["json", "csv"]),
  mapping: z.record(z.string()).optional(), replace: z.boolean().default(false),
});
type ImportRequest = z.infer<typeof importRequest>;

export async function runImport(input: ImportRequest, commit: boolean) {
  const { content, format, replace } = input;
  const file = parseFile(content, format);
  if (replace && !file.metadata) throw new InputError("覆盖恢复需要 ThreadVault JSON 备份");
  const mapping: Mapping = (!replace && input.mapping) || Object.fromEntries(fields.map((field) =>
    [field, [field, ...(aliases[field] ?? [])].find((name) => file.headers.includes(name)) ?? ""]));
  return db.$transaction(async (client) => {
    const existing = replace ? [] : await client.post.findMany({ select: { url: true, sourcePostId: true } });
    const urls = new Set(existing.map(({url}) => url).filter(Boolean));
    const ids = new Set(existing.map(({sourcePostId}) => sourcePostId).filter(Boolean));
    const errors: { row: number; message: string }[] = [];
    const accepted: Draft[] = [];
    let duplicates = 0;
    file.rows.forEach((row, index) => {
      try {
        if (!row || typeof row !== "object" || Array.isArray(row)) throw new InputError("帖子必须是对象");
        const draft = mapRow(row, mapping);
        if ((draft.url && urls.has(draft.url)) || (draft.sourcePostId && ids.has(draft.sourcePostId))) { duplicates++; return; }
        if (draft.url) urls.add(draft.url);
        if (draft.sourcePostId) ids.add(draft.sourcePostId);
        accepted.push(draft);
      } catch (error) {
        errors.push({ row: index + (format === "csv" ? 2 : 1), message: error instanceof z.ZodError
          ? error.issues.map(({path, message}) => `${path.join(".")}：${message}`).join("；")
          : error instanceof Error ? error.message : "数据无效" });
      }
    });
    if (commit) {
      if (replace && (errors.length || duplicates)) throw new InputError("备份含有无效或重复数据，已取消覆盖恢复");
      if (replace) {
        await client.post.deleteMany();
        await client.category.deleteMany();
        await client.tag.deleteMany();
      }
      if (file.metadata) {
        for (const category of file.metadata.categories) await client.category.upsert({
          where: { name: category.name }, create: category, update: {},
        });
        for (const name of file.metadata.tags) await client.tag.upsert({ where: { name }, create: { name }, update: {} });
      }
      for (const draft of accepted) await client.post.create({ data: rowData(draft) });
    }
    return {
      headers: file.headers, mapping, errors: errors.slice(0, 100), invalid: errors.length, duplicates,
      valid: accepted.length, total: file.rows.length, backup: !!file.metadata,
      sample: accepted.slice(0, 5).map(({ text, url, authorName, authorHandle }) => ({text, url, authorName, authorHandle})),
    };
  }, { timeout: 120000 });
}

export async function exportVault(format: "json" | "csv") {
  const backup = await db.$transaction(async (client) => {
    const posts = (await client.post.findMany({ include: relations, orderBy: { importedAt: "desc" } })).map(serialize)
      .map(({ id: _id, categories, tags, ...post }) => ({ ...post, categories: categories.map(({name}) => name), tags: tags.map(({name}) => name) }));
    const categories = await client.category.findMany({ select: { name: true, color: true } });
    const tags = await client.tag.findMany({ select: { name: true } });
    return { format: "threadvault", version: 1, exportedAt: new Date().toISOString(), categories, tags: tags.map(({name}) => name), posts };
  });
  return format === "json" ? JSON.stringify(backup, null, 2) : "\uFEFF" + Papa.unparse({
    fields: [...fields],
    data: backup.posts.map((post) => fields.map((field) => {
      const value = post[field];
      return Array.isArray(value) ? JSON.stringify(value) : value;
    })),
  }, { escapeFormulae: true });
}
