import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "ThreadVault · 收藏工作台",
  description: "你的 Threads 私人知识库",
};

const themeScript = "try{const t=localStorage.getItem('threadvault-theme');document.documentElement.classList.toggle('dark',t==='dark'||(!t&&matchMedia('(prefers-color-scheme: dark)').matches))}catch{}";

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="zh-CN" suppressHydrationWarning><head><script dangerouslySetInnerHTML={{__html:themeScript}} /></head><body>{children}</body></html>;
}
