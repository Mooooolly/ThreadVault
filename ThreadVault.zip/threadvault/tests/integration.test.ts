import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import test from "node:test";

test("SQLite and route integration: CRUD, FTS, filters, bulk, import, export and restore", async () => {
  const folder = mkdtempSync(join(tmpdir(), "threadvault-test-"));
  process.env.DATABASE_URL = `file:${join(folder, "integration.db")}`;
  delete process.env.AI_API_KEY;
  const { db } = await import("../lib/db");
  try {
    for (let run = 0; run < 2; run++) execFileSync(process.execPath, ["--import", "tsx", "prisma/migrate.ts"]);
    const { GET, POST } = await import("../app/api/vault/route");
    const base = "http://localhost:3000/api/vault";
    type VaultData = import("../lib/types").VaultData;
    type Post = import("../lib/types").Post;
    const write = (action: string, data?: unknown, id?: string) => POST(new Request(base, {
      method: "POST", headers: {"content-type":"application/json"}, body: JSON.stringify({action, data, id}),
    }));
    const query = async (params: Record<string, string> = {}): Promise<VaultData> => {
      const response = await GET(new Request(`${base}?${new URLSearchParams(params)}`));
      assert.equal(response.status, 200);
      return response.json();
    };
    assert.equal((await query()).categories.length, 6);
    const categoryResponse = await write("saveCategory", {name:"手工归档", color:"blue"});
    assert.equal(categoryResponse.status, 200);
    const custom = await categoryResponse.json();
    const raw = {url:"https://threads.net/@Tester/post/CaseABC?x=1", authorName:"张三", text:"一份独立游戏设计指南", categories:["手工归档"], tags:["像素艺术"], note:"私有注释", priority:3};
    const created = await write("savePost", raw);
    assert.equal(created.status, 200);
    const item = await created.json() as Post;
    assert.equal(item.authorHandle, "tester");
    assert.equal((await write("savePost", {...raw, url:"https://threads.com/t/CaseABC"})).status, 409);
    assert.equal((await query({ q:"游戏设计 像素", author:"@tester", category:custom.id, tag:"像素艺术", sort:"priority", scope:"recent" })).posts[0]?.id, item.id);
    assert.equal((await query({q:"注释"})).posts.length, 1);
    const recommendation = await write("suggest", undefined, item.id);
    assert.equal((await recommendation.json()).method, "rules");
    assert.deepEqual((await query()).posts[0].categories.map(({name}) => name), ["手工归档"]);
    const edited = await write("savePost", {...raw, text:"更新后的关卡说明", note:"新备注", tags:["关卡"], categories:["手工归档", "游戏"]}, item.id);
    assert.equal(edited.status, 200);
    assert.deepEqual(new Set((await edited.json() as Post).categories.map(({name}) => name)), new Set(["手工归档","游戏"]));
    assert.equal((await query({q:"像素艺术"})).posts.length, 0);
    assert.equal((await query({q:"独立游戏"})).posts.length, 0);
    assert.equal((await query({q:"关卡说明"})).posts.length, 1);
    assert.equal((await write("bulk", {ids:[item.id], operation:"status", readStatus:"read"})).status, 200);
    assert.equal((await query({status:"read"})).posts[0].id, item.id);
    assert.equal((await write("saveCategory", {name:"已归档", color:"blue"}, custom.id)).status, 200);
    assert.equal((await query({q:"已归档"})).posts.length, 1);
    const importData = {format:"csv", content:"网页,内容,作者\nhttps://threads.com/t/CaseABC,旧内容,张三\nhttps://threads.com/t/Fresh123,学习知识测试,李四\n错误网址,错误,五", mapping:{url:"网页",text:"内容",authorName:"作者"}};
    const previewResponse = await write("previewImport", importData);
    assert.equal(previewResponse.status, 200);
    const preview = await previewResponse.json();
    assert.deepEqual([preview.valid, preview.duplicates, preview.invalid], [1,1,1]);
    assert.equal((await query()).stats.total, 1);
    assert.equal((await write("commitImport", importData)).status, 200);
    assert.equal((await query()).stats.total, 2);
    const csv = await GET(new Request(base + "?export=csv"));
    assert.match(await csv.text(), /学习知识测试/);
    const backup = await (await GET(new Request(base + "?export=json"))).text();
    assert.equal(JSON.parse(backup).posts.length, 2);
    assert.equal((await write("deleteCategory", undefined, custom.id)).status, 200);
    assert.equal((await write("deletePost", undefined, item.id)).status, 200);
    assert.equal((await query({q:"关卡说明"})).posts.length, 0);
    assert.equal((await write("commitImport", {format:"json", content:backup, replace:true})).status, 200);
    const restored = await query({q:"关卡说明", status:"read"});
    assert.equal(restored.posts[0].note, "新备注");
    assert.ok(restored.categories.some(({name}) => name === "已归档"));
    assert.equal((await write("bulk", {ids: restored.posts.map(({id}) => id), operation:"delete"})).status, 200);
    assert.equal((await query({q:"关卡说明"})).posts.length, 0);
  } finally {
    await db.$disconnect();
    rmSync(folder, { recursive: true, force: true });
  }
});
