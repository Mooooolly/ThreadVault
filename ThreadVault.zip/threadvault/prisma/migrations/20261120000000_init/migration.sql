CREATE TABLE "Post" (
  "id" TEXT NOT NULL PRIMARY KEY, "source" TEXT NOT NULL DEFAULT 'Threads',
  "sourcePostId" TEXT, "url" TEXT, "authorName" TEXT NOT NULL DEFAULT '',
  "authorHandle" TEXT NOT NULL DEFAULT '', "text" TEXT NOT NULL DEFAULT '',
  "imageUrls" TEXT NOT NULL DEFAULT '[]', "publishedAt" DATETIME,
  "importedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "note" TEXT NOT NULL DEFAULT '', "priority" INTEGER NOT NULL DEFAULT 0,
  "readStatus" TEXT NOT NULL DEFAULT 'unread', "aiSummary" TEXT NOT NULL DEFAULT '',
  "isDemo" BOOLEAN NOT NULL DEFAULT false
);
CREATE UNIQUE INDEX "Post_sourcePostId_key" ON "Post"("sourcePostId");
CREATE UNIQUE INDEX "Post_url_key" ON "Post"("url");
CREATE INDEX "Post_importedAt_idx" ON "Post"("importedAt");
CREATE TABLE "Category" ("id" TEXT NOT NULL PRIMARY KEY,"name" TEXT NOT NULL,"color" TEXT NOT NULL DEFAULT 'slate');
CREATE UNIQUE INDEX "Category_name_key" ON "Category"("name");
INSERT INTO "Category" ("id","name","color") VALUES
  ('default-ai','AI 工具','violet'), ('default-marketing','市场营销','orange'),
  ('default-game','游戏','blue'), ('default-study','学习知识','green'),
  ('default-life','生活灵感','pink'), ('default-other','其他','slate');
CREATE TABLE "Tag" ("id" TEXT NOT NULL PRIMARY KEY,"name" TEXT NOT NULL);
CREATE UNIQUE INDEX "Tag_name_key" ON "Tag"("name");
CREATE TABLE "_CategoryToPost" ("A" TEXT NOT NULL REFERENCES "Category"("id") ON DELETE CASCADE ON UPDATE CASCADE,"B" TEXT NOT NULL REFERENCES "Post"("id") ON DELETE CASCADE ON UPDATE CASCADE, PRIMARY KEY ("A","B"));
CREATE INDEX "_CategoryToPost_B_index" ON "_CategoryToPost"("B");
CREATE TABLE "_PostToTag" ("A" TEXT NOT NULL REFERENCES "Post"("id") ON DELETE CASCADE ON UPDATE CASCADE,"B" TEXT NOT NULL REFERENCES "Tag"("id") ON DELETE CASCADE ON UPDATE CASCADE, PRIMARY KEY ("A","B"));
CREATE INDEX "_PostToTag_B_index" ON "_PostToTag"("B");
CREATE VIRTUAL TABLE PostSearch USING fts5(text, authorName, authorHandle, note, aiSummary, tokenize='trigram');
CREATE TRIGGER post_search_insert AFTER INSERT ON Post BEGIN
  INSERT INTO PostSearch(rowid,text,authorName,authorHandle,note,aiSummary)
  VALUES (new.rowid,new.text,new.authorName,new.authorHandle,new.note,new.aiSummary);
END;
CREATE TRIGGER post_search_update AFTER UPDATE ON Post BEGIN
  DELETE FROM PostSearch WHERE rowid=old.rowid;
  INSERT INTO PostSearch(rowid,text,authorName,authorHandle,note,aiSummary)
  VALUES (new.rowid,new.text,new.authorName,new.authorHandle,new.note,new.aiSummary);
END;
CREATE TRIGGER post_search_delete AFTER DELETE ON Post BEGIN
  DELETE FROM PostSearch WHERE rowid=old.rowid;
END;
