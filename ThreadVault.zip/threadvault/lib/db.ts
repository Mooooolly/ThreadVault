import { PrismaBetterSqlite3 } from "@prisma/adapter-better-sqlite3";
import { PrismaClient } from "@/generated/prisma/client";

const globalCache = globalThis as typeof globalThis & { threadVaultDb?: PrismaClient };
export const db = globalCache.threadVaultDb ?? new PrismaClient({
  adapter: new PrismaBetterSqlite3({ url: process.env.DATABASE_URL || "file:./prisma/threadvault.db" }),
});
if (process.env.NODE_ENV !== "production") globalCache.threadVaultDb = db;
