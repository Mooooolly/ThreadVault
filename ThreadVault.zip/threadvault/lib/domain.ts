import { z } from "zod";

export const defaults = [
  ["AI 工具", "violet"], ["市场营销", "orange"], ["游戏", "blue"],
  ["学习知识", "green"], ["生活灵感", "pink"], ["其他", "slate"],
] as const;
export const colors = defaults.map(([, color]) => color);
export const statuses = ["unread", "reading", "read"] as const;
const list = z.array(z.string().trim().min(1).max(60)).max(50).default([])
  .transform((values) => Array.from(new Set(values)));
const date = z.string().trim().refine((value) => !value || !Number.isNaN(Date.parse(value)), "日期无效")
  .nullish().transform((value) => value ? new Date(value) : null);
const image = z.string().trim().max(4000).refine((value) => {
  if (/^\/demo-[a-z]+\.svg$/.test(value)) return true;
  try { const parsed = new URL(value); return ["http:", "https:"].includes(parsed.protocol) && !parsed.username && !parsed.password; }
  catch { return false; }
}, "图片需要使用有效的 HTTP 或 HTTPS 链接");
export const draftSchema = z.object({
  url: z.string().trim().max(4000).nullish(),
  source: z.string().trim().max(80).default("Threads").transform((value) => value || "Threads"),
  sourcePostId: z.string().trim().max(120).nullish(),
  authorName: z.string().trim().max(150).default(""),
  authorHandle: z.string().trim().max(150).default("").transform((value) => value.replace(/^@+/, "")),
  text: z.string().max(50000).default(""),
  imageUrls: z.array(image).max(20).default([]).transform((values) => Array.from(new Set(values))),
  publishedAt: date,
  importedAt: date,
  note: z.string().max(20000).default(""),
  priority: z.coerce.number().int().min(0).max(3).default(0),
  readStatus: z.enum(statuses).default("unread"),
  aiSummary: z.string().max(2000).default(""),
  categories: list,
  tags: list,
  isDemo: z.boolean().default(false),
});
export type Draft = ReturnType<typeof normalizeDraft>;
export class InputError extends Error {}

export function canonicalThreadsUrl(value: string) {
  let parsed: URL;
  try { parsed = new URL(value); }
  catch { throw new InputError("请填写有效的 Threads 原帖链接"); }
  const match = /^\/(?:@([\w.]+)\/)?(?:post|t)\/([\w-]+)\/?$/i.exec(parsed.pathname);
  if (!["https:", "http:"].includes(parsed.protocol) || parsed.username || parsed.password || parsed.port ||
      !/^(?:(?:www|m)\.)?threads\.(?:net|com)$/i.test(parsed.hostname) || !match) {
    throw new InputError("请填写有效的 Threads 原帖链接");
  }
  const [, handle, id] = match;
  return { id, handle: handle?.toLowerCase(), url: `https://www.threads.com/${handle ? `@${handle.toLowerCase()}/post` : "t"}/${id}` };
}

export function normalizeDraft(input: unknown) {
  const { url, sourcePostId, authorHandle, ...fields } = draftSchema.parse(input);
  if (!url && !fields.text.trim() && !fields.imageUrls.length) throw new InputError("请至少填写链接、正文或图片");
  const link = url ? canonicalThreadsUrl(url) : null;
  if (link && sourcePostId && sourcePostId !== link.id) throw new InputError("帖子 ID 与原帖链接不一致");
  return { ...fields, url: link?.url ?? null, sourcePostId: link?.id ?? (sourcePostId || null), authorHandle: authorHandle || link?.handle || "" };
}
