import { db } from "@/lib/db";
import { normalizeDraft, defaults, type Draft } from "@/lib/domain";
import { searchQuery } from "@/lib/search";
import type { Prisma } from "@/generated/prisma/client";
import type { Post, VaultData } from "@/lib/types";

export const relations = { categories: { orderBy: { name: "asc" } }, tags: { orderBy: { name: "asc" } } } as const;
export type RecordWithRelations = Prisma.PostGetPayload<{ include: typeof relations }>;

export function serialize(post: RecordWithRelations): Post {
  return {
    ...post, imageUrls: JSON.parse(post.imageUrls) as string[],
    publishedAt: post.publishedAt?.toISOString() ?? null, importedAt: post.importedAt.toISOString(),
  };
}

export async function ensureDefaults(client: Prisma.TransactionClient = db) {
  for (const [name, color] of defaults) await client.category.upsert({ where: { name }, create: { name, color }, update: {} });
}

export function rowData(draft: Draft) {
  const { categories, tags, imageUrls, importedAt, ...fields } = draft;
  return {
    ...fields, imageUrls: JSON.stringify(imageUrls), importedAt: importedAt ?? new Date(),
    categories: { connectOrCreate: categories.map((name) => ({where: { name }, create: { name }})) },
    tags: { connectOrCreate: tags.map((name) => ({where: { name }, create: { name }})) },
  };
}

export async function savePost(input: unknown, id?: string) {
  const draft = normalizeDraft(input);
  const data = rowData(draft);
  if (!id) return serialize(await db.post.create({ data: { ...data, isDemo: false, importedAt: new Date() }, include: relations }));
  const { importedAt: _timestamp, isDemo: _demo, categories, tags, ...editable } = data;
  return serialize(await db.post.update({
    where: { id }, include: relations,
    data: { ...editable, categories: { set: [], ...categories }, tags: { set: [], ...tags } },
  }));
}

export async function listVault(params = new URLSearchParams()): Promise<VaultData> {
  const recent = new Date(Date.now() - 7 * 86400000);
  const [ids, categories, tags, total, recentCount, pending] = await Promise.all([
    db.$queryRaw<{ id: string }[]>(searchQuery(params, recent)),
    db.category.findMany({ orderBy: { name: "asc" }, include: { _count: { select: { posts: true } } } }),
    db.tag.findMany({ where: { posts: { some: {} } }, orderBy: { name: "asc" }, select: { name: true } }),
    db.post.count(),
    db.post.count({ where: { importedAt: { gte: recent } } }),
    db.post.count({ where: { categories: { none: {} } } }),
  ]);
  const records: RecordWithRelations[] = [];
  for (let offset = 0; offset < ids.length; offset += 500) {
    records.push(...await db.post.findMany({ where: { id: { in: ids.slice(offset, offset + 500).map(({ id }) => id) } }, include: relations }));
  }
  const byId = new Map(records.map((post) => [post.id, post]));
  return {
    posts: ids.flatMap(({ id }) => { const post = byId.get(id); return post ? [serialize(post)] : []; }),
    categories: categories.map(({_count, ...category}) => ({...category, count: _count.posts})),
    tags: tags.map(({name}) => name), stats: { total, recent: recentCount, pending },
  };
}
