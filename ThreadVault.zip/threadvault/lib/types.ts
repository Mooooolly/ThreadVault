export type Category = { id: string; name: string; color: string };
export type Post = {
  id: string; source: string; sourcePostId: string | null; url: string | null;
  authorName: string; authorHandle: string; text: string; imageUrls: string[];
  publishedAt: string | null; importedAt: string; note: string; priority: number;
  readStatus: string; aiSummary: string; isDemo: boolean;
  categories: Category[]; tags: { id: string; name: string }[];
};
export type Suggestion = { categories: string[]; tags: string[]; summary: string; method: "model" | "rules" };
export type VaultData = {
  posts: Post[];
  categories: (Category & { count: number })[];
  tags: string[];
  stats: { total: number; recent: number; pending: number };
};
