import { z } from "zod";
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { colors, InputError, statuses } from "@/lib/domain";
import { listVault, relations, savePost, serialize } from "@/lib/posts";
import { exportVault, importRequest, runImport } from "@/lib/importing";
import { suggest } from "@/lib/ai";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

function errorResponse(error: unknown) {
  if (error instanceof InputError) return NextResponse.json({ error: error.message }, { status: 400 });
  if (error instanceof z.ZodError) return NextResponse.json({ error: error.issues.map(({path, message}) => `${path.join(".")} ${message}`).join("；") }, { status: 400 });
  const code = error && typeof error === "object" && "code" in error ? error.code : null;
  if (code === "P2002") return NextResponse.json({ error: "链接、帖子编号或分类名称已存在" }, { status: 409 });
  if (code === "P2025") return NextResponse.json({ error: "记录已不存在，请刷新后重试" }, { status: 404 });
  console.error(error);
  return NextResponse.json({ error: "操作失败，请确认本地数据库已初始化后重试" }, { status: 500 });
}

export async function GET(request: Request) {
  try {
    const params = new URL(request.url).searchParams;
    const format = params.get("export");
    if (format === "json" || format === "csv") {
      return new Response(await exportVault(format), {headers: {
        "content-type": format === "json" ? "application/json; charset=utf-8" : "text/csv; charset=utf-8",
        "content-disposition": `attachment; filename="threadvault-${new Date().toISOString().slice(0,10)}.${format}"`,
        "cache-control": "no-store",
      }});
    }
    return NextResponse.json(await listVault(params), {headers: {"cache-control": "no-store"}});
  } catch (error) { return errorResponse(error); }
}

const idValue = z.string().min(1).max(150);
const categorySchema = z.object({
  name: z.string().trim().min(1).max(60), color: z.enum(colors as [(typeof colors)[number], ...(typeof colors)[number][]]).default("slate"),
});
const bulkSchema = z.object({
  ids: z.array(idValue).min(1).max(10000),
  operation: z.enum(["delete", "status", "category"]),
  readStatus: z.enum(statuses).optional(), categoryId: idValue.optional(),
});

export async function POST(request: Request) {
  try {
    if (!request.headers.get("content-type")?.startsWith("application/json")) throw new InputError("请求需要 JSON 格式");
    let input;
    try { input = await request.json(); } catch { throw new InputError("请求内容不是有效的 JSON"); }
    const body = z.object({ action: z.string(), id: idValue.optional(), data: z.unknown() }).parse(input);
    const { action, data } = body;
    const identifier = () => idValue.parse(body.id);
    switch (action) {
      case "savePost": return NextResponse.json(await savePost(data, body.id));
      case "deletePost": {
        await db.post.delete({where: {id: identifier()}});
        return NextResponse.json({ ok: true });
      }
      case "saveCategory": {
        const values = categorySchema.parse(data);
        const category = body.id ? await db.category.update({ where: {id: body.id}, data: values })
          : await db.category.create({ data: values });
        return NextResponse.json(category);
      }
      case "deleteCategory": {
        await db.category.delete({ where: { id: identifier() } });
        return NextResponse.json({ok: true});
      }
      case "previewImport":
      case "commitImport":
        return NextResponse.json(await runImport(importRequest.parse(data), action === "commitImport"));
      case "suggest": {
        const [post, categories] = await Promise.all([
          db.post.findUniqueOrThrow({ where: { id: identifier() }, include: relations }),
          db.category.findMany(),
        ]);
        return NextResponse.json(await suggest(serialize(post), categories));
      }
      case "bulk": {
        const values = bulkSchema.parse(data);
        const ids = [...new Set(values.ids)];
        await db.$transaction(async (client) => {
          for (let offset = 0; offset < ids.length; offset += 500) {
            const batch = ids.slice(offset, offset + 500);
            const where = { id: { in: batch } };
            if (values.operation === "delete") await client.post.deleteMany({ where });
            if (values.operation === "status") await client.post.updateMany({ where, data: { readStatus: z.enum(statuses).parse(values.readStatus) } });
            if (values.operation === "category") {
              const category = await client.category.findUniqueOrThrow({ where: { id: idValue.parse(values.categoryId) } });
              await client.category.update({ where: { id: category.id }, data: { posts: { connect: batch.map((id) => ({ id })) } } });
            }
          }
        }, { timeout: 30000 });
        return NextResponse.json({ok: true});
      }
      default: throw new InputError("未知操作");
    }
  } catch (error) { return errorResponse(error); }
}
