import { Prisma } from "@/generated/prisma/client";

export interface SemanticSearchProvider {
  search(query: string, limit: number): Promise<{ postId: string; score: number }[]>;
}

const sortable = {
  imported: Prisma.sql`julianday(p.importedAt) DESC`,
  published: Prisma.sql`julianday(p.publishedAt) DESC, julianday(p.importedAt) DESC`,
  priority: Prisma.sql`p.priority DESC, julianday(p.importedAt) DESC`,
};

export function searchQuery(params: URLSearchParams, recent: Date) {
  const clauses: Prisma.Sql[] = [];
  for (const token of (params.get("q") ?? "").trim().slice(0, 240).split(/\s+/u).filter(Boolean)) {
    const phrase = `"${token.replaceAll('"', '""')}"`;
    const textMatch = Array.from(token).length >= 3 && /[\p{L}\p{N}]/u.test(token)
      ? Prisma.sql`p.rowid IN (SELECT rowid FROM PostSearch WHERE PostSearch MATCH ${phrase})`
      : Prisma.sql`(instr(lower(p.text),lower(${token})) > 0 OR instr(lower(p.authorName),lower(${token})) > 0
        OR instr(lower(p.authorHandle),lower(${token})) > 0 OR instr(lower(p.note),lower(${token})) > 0
        OR instr(lower(p.aiSummary),lower(${token})) > 0)`;
    clauses.push(Prisma.sql`(${textMatch}
      OR EXISTS (SELECT 1 FROM "_CategoryToPost" r JOIN Category c ON r."A"=c.id
        WHERE r."B"=p.id AND instr(lower(c.name),lower(${token})) > 0)
      OR EXISTS (SELECT 1 FROM "_PostToTag" r JOIN Tag t ON r."B"=t.id
        WHERE r."A"=p.id AND instr(lower(t.name),lower(${token})) > 0))`);
  }
  const author = params.get("author")?.slice(0, 150).replace(/^@/, "");
  if (author) clauses.push(Prisma.sql`(instr(lower(p.authorName),lower(${author})) > 0 OR instr(lower(p.authorHandle),lower(${author})) > 0)`);
  const category = params.get("category");
  if (category) clauses.push(Prisma.sql`EXISTS (SELECT 1 FROM "_CategoryToPost" r WHERE r."B"=p.id AND r."A"=${category})`);
  const tag = params.get("tag");
  if (tag) clauses.push(Prisma.sql`EXISTS (SELECT 1 FROM "_PostToTag" r JOIN Tag t ON r."B"=t.id WHERE r."A"=p.id AND t.name=${tag})`);
  const state = params.get("status");
  if (state) clauses.push(Prisma.sql`p.readStatus=${state}`);
  if (params.get("scope") === "recent") clauses.push(Prisma.sql`julianday(p.importedAt) >= julianday(${recent.toISOString()})`);
  if (params.get("scope") === "pending") clauses.push(Prisma.sql`NOT EXISTS (SELECT 1 FROM "_CategoryToPost" r WHERE r."B"=p.id)`);
  const sort = params.get("sort");
  const order = sort === "published" || sort === "priority" ? sortable[sort] : sortable.imported;
  const where = clauses.length ? Prisma.sql`WHERE ${Prisma.join(clauses, " AND ")}` : Prisma.empty;
  return Prisma.sql`SELECT p.id FROM Post p ${where} ORDER BY ${order}, p.id`;
}
