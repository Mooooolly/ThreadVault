import "dotenv/config";
import { db } from "@/lib/db";
import { ensureDefaults, rowData } from "@/lib/posts";
import { normalizeDraft } from "@/lib/domain";

const demos = [
  { handle: "pixelnotes", author: "林川", text: "整理了一套我每天都在用的 AI 创作工作流。从收集灵感、拆解需求到生成初稿，最终还是要留一点时间给手工判断。", categories: ["AI 工具"], tags: ["工作流", "提示词"], image: "ai", priority: 3 },
  { handle: "brandjournal", author: "Mia 陈", text: "想做出有记忆点的品牌，先写清楚这一句：当谁遇到什么问题时，为什么会第一个想到你？一个实用的品牌定位练习。", categories: ["市场营销"], tags: ["品牌策略", "内容创作"], image: "brand", priority: 2 },
  { handle: "indiecorner", author: "周野", text: "最近在研究独立游戏里的环境叙事。最喜欢用光线和物件摆放交代背景的关卡，一个提示都没有，但你就是知道发生过什么。", categories: ["游戏"], tags: ["独立游戏", "设计"], image: "game", priority: 1 },
  { handle: "noteswithlin", author: "林小满", text: "我的阅读笔记只留三件事：一句核心观点，一个能用上的例子，一个还没解决的问题。读完一周回来看，往往最后一栏最有用。", categories: ["学习知识"], tags: ["阅读", "笔记方法"], priority: 2 },
  { handle: "slowandsteady", author: "阿岚", text: "周末找了条没走过的路，一杯咖啡和一台旧相机就够了。偶尔把日程表留白，比把一天安排好更难，也更值得。", categories: ["生活灵感"], tags: ["摄影", "周末"] },
  { handle: "buildinpublic", author: "陈然", text: "做个人项目的一个小经验：把第一版定义成一件能完整完成的小事。先做出闭环，数据和反馈才会给下一步定方向。", categories: ["学习知识", "AI 工具"], tags: ["产品", "效率"] },
  { handle: "keptthoughts", author: "吴桐", text: "有一些灵感只适合先收起来。最近看到一份关于城市步行路线的手绘地图，想找时间沿着它走一遍。", categories: [], tags: [], priority: 1 },
  { handle: "growthsketch", author: "沈宁", text: "内容增长的第一步是问清楚读者为什么会转发：表达观点、帮助朋友、还是收藏一份稍后能用上的资料？", categories: ["市场营销"], tags: ["增长", "内容创作"] },
  { handle: "tinyhabits", author: "乐也", text: "把每天的收尾动作缩小到两分钟：关掉照片软件之前，挑一张今天的照片留下。慢慢就有了一本自己的日历。", categories: ["生活灵感"], tags: ["习惯"] },
];

async function seed() {
  await db.$transaction(async (client) => {
    await ensureDefaults(client);
    for (const [index, demo] of demos.entries()) {
      const sourcePostId = `ThreadVaultDemo${index + 1}`;
      const importedAt = new Date(Date.now() - (index < 6 ? index : index + 2) * 86400000 - 3600000);
      const draft = normalizeDraft({
        sourcePostId, authorName: demo.author, authorHandle: demo.handle, text: demo.text,
        categories: demo.categories, tags: demo.tags, imageUrls: demo.image ? [`/demo-${demo.image}.svg`] : [],
        priority: demo.priority ?? 0, readStatus: index % 4 === 3 ? "read" : index % 4 === 1 ? "reading" : "unread",
        importedAt: importedAt.toISOString(), publishedAt: new Date(+importedAt - 86400000).toISOString(), isDemo: true,
        note: index === 0 ? "试着把这套流程整理成自己的模板。" : "",
      });
      await client.post.upsert({where: {sourcePostId}, create: rowData(draft), update: {}});
    }
  });
  console.log("9 demo posts ready.");
}

seed().catch((error) => { console.error(error); process.exitCode = 1; }).finally(() => db.$disconnect());
