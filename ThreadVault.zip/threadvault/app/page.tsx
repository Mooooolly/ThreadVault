import { Vault } from "@/components/vault";
import { listVault } from "@/lib/posts";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export default async function Home() {
  try { return <Vault initial={await listVault()} />; }
  catch { return <Vault initial={{posts: [], categories: [], tags: [], stats: {total: 0, recent: 0, pending: 0}}} initialError="无法读取本地数据库。请运行 npm run db:migrate 后重试。" />; }
}
