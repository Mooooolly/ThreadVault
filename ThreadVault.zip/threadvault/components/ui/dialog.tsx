"use client";
import * as Dialog from "@radix-ui/react-dialog";
import { X } from "lucide-react";
import type { ReactNode } from "react";
import { Button } from "@/components/ui/button";

export function Modal({title, description, onClose, children, side = false, wide = false}: {
  title: string; description?: string; onClose: () => void; children: ReactNode; side?: boolean; wide?: boolean;
}) {
  return <Dialog.Root open onOpenChange={(open) => { if (!open) onClose(); }}>
    <Dialog.Portal>
      <Dialog.Overlay className="overlay" />
      <Dialog.Content className={side ? "dialog detail-dialog" : `dialog modal ${wide ? "modal-wide" : ""}`} {...(description ? {} : {"aria-describedby": undefined})}>
        <header className="dialog-heading">
          <div><Dialog.Title>{title}</Dialog.Title>{description && <Dialog.Description>{description}</Dialog.Description>}</div>
          <Dialog.Close asChild><Button variant="ghost" className="icon-button" aria-label="关闭"><X size={19}/></Button></Dialog.Close>
        </header>
        {children}
      </Dialog.Content>
    </Dialog.Portal>
  </Dialog.Root>;
}
