import assert from "node:assert/strict";
import test from "node:test";
import { canonicalThreadsUrl, normalizeDraft } from "../lib/domain";
import { ruleSuggestion, suggest } from "../lib/ai";
import { createServer } from "node:http";
import type { Post } from "../lib/types";

test("normalizes Threads domains and strips tracking without changing case-sensitive IDs", () => {
  const url = canonicalThreadsUrl("http://threads.net/@USER/post/aAb-34/?igsh=abc#top");
  assert.deepEqual(url, { id: "aAb-34", handle: "user", url: "https://www.threads.com/@user/post/aAb-34" });
  assert.equal(canonicalThreadsUrl("https://www.threads.com/t/aAb-34").id, url.id);
});

test("rejects non-post links, bad image schemes, empty content and mismatched IDs", () => {
  for (const url of ["https://threads.com.example.com/@a/post/z", "https://threads.com/@a", "https://a:b@threads.com/t/A", "invalid"]) {
    assert.throws(() => canonicalThreadsUrl(url), /Threads/);
  }
  assert.throws(() => normalizeDraft({ text: "", imageUrls: ["javascript:alert(1)"] }));
  assert.throws(() => normalizeDraft({ text: " " }), /至少填写/);
  assert.throws(() => normalizeDraft({ url:"https://threads.com/t/A", sourcePostId:"B" }), /不一致/);
  assert.equal(normalizeDraft({ url:"https://threads.com/t/A" }).text, "");
});

test("recommends multiple categories locally and handles link-only items", () => {
  const categories = [{name:"AI 工具"}, {name:"游戏"}, {name:"其他"}];
  const result = ruleSuggestion({text:"用 AI 写独立游戏的提示词"}, categories);
  assert.deepEqual(result.categories, ["AI 工具","游戏"]);
  assert.ok(result.tags.includes("提示词"));
  assert.deepEqual(ruleSuggestion({text:""}, categories).categories, []);
  assert.deepEqual(ruleSuggestion({text:"email"}, categories).categories, ["其他"]);
});

test("uses the configured model endpoint, validates labels, and falls back on invalid output", async () => {
  let malformed = false;
  const requests: { authorization: string | undefined; path: string | undefined; body: string }[] = [];
  const server = createServer(async (request, response) => {
    let body = "";
    for await (const chunk of request) body += chunk;
    requests.push({ authorization: request.headers.authorization, path: request.url, body });
    response.setHeader("content-type", "application/json");
    response.end(JSON.stringify({ choices: [{ message: { content: malformed ? "invalid" :
      JSON.stringify({categories:["AI 工具","不存在"], tags:["提示词"], summary:"一则 AI 提示词笔记"}) } }] }));
  });
  await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
  const address = server.address();
  assert.ok(address && typeof address !== "string");
  const settings = { AI_API_KEY:"test-key", AI_BASE_URL:`http://127.0.0.1:${address.port}/v1/`, AI_MODEL:"test-model" };
  const previous = Object.fromEntries(Object.keys(settings).map((key) => [key, process.env[key]]));
  Object.assign(process.env, settings);
  const post: Post = {
    id:"post", source:"Threads", sourcePostId:null, url:null, authorName:"", authorHandle:"",
    text:"用 AI 测试提示词", imageUrls:[], publishedAt:null, importedAt:new Date().toISOString(), note:"私人测试备注",
    priority:0, readStatus:"unread", aiSummary:"", isDemo:false, categories:[], tags:[],
  };
  const categories = [{id:"ai",name:"AI 工具",color:"violet"}];
  try {
    const output = await suggest(post, categories);
    assert.equal(output.method, "model");
    assert.deepEqual(output.categories, ["AI 工具"]);
    assert.equal(requests[0].authorization, "Bearer test-key");
    assert.equal(requests[0].path, "/v1/chat/completions");
    assert.equal(JSON.parse(requests[0].body).model, "test-model");
    assert.ok(!requests[0].body.includes(post.note));
    malformed = true;
    assert.equal((await suggest(post, categories)).method, "rules");
  } finally {
    for (const [key, value] of Object.entries(previous)) {
      if (value === undefined) delete process.env[key]; else process.env[key] = value;
    }
    await new Promise<void>((resolve) => server.close(() => resolve()));
  }
});
